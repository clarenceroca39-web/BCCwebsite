<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>BCC - Contact</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'header.php'; ?>

<!-- Hero Section -->
<section class="hero">
  <h1>Contact Us</h1>
  <p>We’d love to hear from you</p>
</section>

<main class="container">
  <section>
    <h2>Get in Touch</h2>

    <!-- Contact Info Cards -->
    <div class="contact-info">
      <div class="contact-card">
        <h3>Address</h3>
        <p>BCC Catholic College, Binalbagan, Negros Occidental</p>
      </div>
      <div class="contact-card">
        <h3>Phone</h3>
        <p>+63 9197369821</p>
      </div>
      <div class="contact-card">
        <h3>Email</h3>
        <p>info@bcc.edu.ph</p>
      </div>
    </div>

    <!-- Modern Contact Form -->
    <form>
      <input type="text" id="name" name="name" placeholder="Your Name" required>
      <input type="email" id="email" name="email" placeholder="Your Email" required>
      <textarea id="message" name="message" rows="5" placeholder="Your Message" required></textarea>
      <button type="submit">Send Message</button>
    </form>
  </section>
</main>

<?php include 'footer.php'; ?>
</body>
</html>
