<div class="top-info-bar">
  <div class="container">
    <div class="hours">Monday - Saturday, 8AM to 10PM</div>
    <div class="phone">Call us now <strong>+63 9197369821</strong></div>
  </div>
</div>

<header>
  <div class="container">
    <nav>
      <div class="logo">BCC</div>
      <ul class="nav-links">
        <li><a href="home.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="courses.php">Courses</a></li>
        <li><a href="teachers.php">Teachers</a></li>
        <li><a href="department.php">Department</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </nav>
  </div>
</header>

