<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>BCC - Departments</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'header.php'; ?>

<section class="hero">
  <h1>Departments</h1>
  <p>Academic Divisions at BCC</p>
</section>

<main class="container">
  <div class="card-grid">

    <!-- Education Department -->
    <div class="card">
      <h3>Education Department</h3>
      <p>
        BS Elementary Education<br>
        BS Secondary Education
      </p>
    </div>

    <!-- CABAIT Department -->
    <div class="card">
      <h3>CABAIT Department</h3>
      <p>
        BSBA - Human Resource Management<br>
        BSBA - Financial Management<br>
        BS Accountancy<br>
        BS Information Technology
      </p>
    </div>

  </div>
</main>

<?php include 'footer.php'; ?>
</body>
</html>
