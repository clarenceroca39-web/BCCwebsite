<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>BCC - Home</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'header.php'; ?>

<section class="hero">
  <h1>Welcome to BCC Catholic College</h1>
  <p>Shaping Leaders with Excellence and Values</p>
</section>

<main class="container">
  <section class="about-grid">
    <div class="about-image">
      <img src="images/bcc-campus.jpg" alt="BCC Catholic College Campus">
    </div>
    <div class="about-content">
      <p>
        Welcome to BCC. We are committed to providing quality education and developing
        students into competent, responsible, and globally competitive individuals.
        Our institution promotes academic excellence, leadership, and character formation.
      </p>
      <p>
        At BCC, we believe that education is the foundation of success. Our programs are
        designed to equip students with practical skills, strong values, and real-world
        experience.
      </p>
    </div>
  </section>
</main>

<?php include 'footer.php'; ?>
</body>
</html>
