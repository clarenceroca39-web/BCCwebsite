<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>BCC - Courses</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'header.php'; ?>

<section class="hero">
  <h1>Our Courses</h1>
  <p>Explore Academic Programs</p>
</section>

<main class="container">
  <div class="card-grid">

    <div class="card">
      <img src="images/education1.jpg" alt="BS Elementary Education">
      <h3>BS Elementary Education</h3>
    </div>

    <div class="card">
      <img src="images/education2.jpg" alt="BS Secondary Education">
      <h3>BS Secondary Education</h3>
    </div>

    <div class="card">
      <img src="images/bsba-hr.jpg" alt="BSBA HR">
      <h3>BSBA - Human Resource Management</h3>
    </div>

    <div class="card">
      <img src="images/bsba-fm.jpg" alt="BSBA FM">
      <h3>BSBA - Financial Management</h3>
    </div>

    <div class="card">
      <img src="images/accounting.jpg" alt="BS Accountancy">
      <h3>BS Accountancy</h3>
    </div>

    <div class="card">
      <img src="images/csc.jpg" alt="BSIT">
      <h3>BS Information Technology</h3>
    </div>

  </div>
</main>

<?php include 'footer.php'; ?>
</body>
</html>
