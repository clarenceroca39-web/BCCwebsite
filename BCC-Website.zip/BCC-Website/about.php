<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>BCC - About</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'header.php'; ?>

<section class="hero">
  <h1>Historical Background</h1>
  <p>Our History, Vision, and Mission</p>
</section>

<main class="container">
  <section class="about-grid">
    <div class="about-image">
      <img src="images/bcc.jpg" alt="BCC Logo">
      <img src="images/mansion.jpg" alt="BCC Mansion">
    </div>
    <div class="about-content">
      <p>
        Binalbagan Catholic College is a diocesan school under the Diocese of Kabankalan. 
        It began as a parochial Catholic High School, founded on June 12, 1949 through the 
        missionary efforts of the Columban Fathers. At that time, there were very few schools 
        of higher education in Negros Occidental, and the Catholic Church saw the need to 
        provide affordable tertiary education in Southern Negros.
      </p>
      <p>
        In 1978–79, leadership was handed over to the Presentation Sisters. Under Sr. Aquilina 
        Nemenzo, BCC launched its program on Social Transformation and became an affiliate of 
        the Education Forum of the Philippines. During critical periods in the country’s history, 
        BCC stood firmly on the side of the oppressed.
      </p>
      <p>
        The 1990s marked a rise in academic competence, with graduates consistently performing 
        above national averages in board examinations. After 50 years of dedicated service, 
        BCC strengthened its commitment to quality Catholic education. In 2010, the institution 
        pursued accreditation, achieving Level I PAASCU status for its BEED and BSBA programs, 
        later elevated to Level II in 2017.
      </p>

      <h2>Vision</h2>
      <p>
        Christ-centered advocates of excellence, social justice, stewardship, and societal 
        transformation in the rapidly changing world.
      </p>

      <h2>Mission</h2>
      <p>
        A Catholic educational institution run by the Presentation Sisters of the Blessed Virgin 
        Mary in the Philippines, inspired by the mission of Christ and the charism of Venerable 
        Nano Nagle. BCC upholds Catholic ideals and provides quality, holistic, and transformative 
        education to 21st century learners through relevant instruction, research, and community 
        outreach by competent and committed educators.
      </p>
    </div>
  </section>
</main>

<?php include 'footer.php'; ?>
</body>
</html>
