<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>BCC - Teachers</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'header.php'; ?>

<section class="hero">
  <h1>Our Teachers</h1>
  <p>Meet the Deans and Faculty of Each Department</p>
</section>

<main class="container">
  <div class="card-grid">

    <!-- Education Department -->
    <div class="card">
      <h3>Education Department</h3>
      <p><strong>Dean:</strong> Noeme F. Luces, EdD</p>
      <p><strong>Faculty:</strong><br>
         Prof. Rolyn Nico<br>
         Prof. Aivan Navallasca<br>
         Prof. Shaira Baldimo<br>
         Prof. Regine Magbanua<br>
         Prof. Estelita Gomez<br>
         Prof. Myrna Denaque<br>
         Prof. Rowena Jancorda<br>
         Prof. Mary Ann Inodeo
      </p>
    </div>

    <!-- CABAIT Department -->
    <div class="card">
      <h3>CABAIT Department</h3>
      <p><strong>Dean:</strong> Grace Servano</p>
      <p><strong>Faculty:</strong><br>
         Prof. Eula Dagunan<br>
         Prof. Archie Saclauso<br>
         Prof. Normel Nullas<br>
         Prof. Lovelight Villanueva<br>
         Prof. Gilbert Calderon<br>
         Prof. Carlo Ebeto<br>
         Prof. Joerub Cornelio
      </p>
    </div>

  </div>
</main>

<?php include 'footer.php'; ?>
</body>
</html>
