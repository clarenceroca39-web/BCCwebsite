<footer>
  <div class="container">
    <p>&copy; <?php echo date("Y"); ?> All Rights Reserved to BCC Catholic College</p>
  </div>
</footer>
